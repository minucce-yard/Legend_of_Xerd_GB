Zerd no Densetsu (Japan).gb


MD-5:  FD280448AE0F60BAE1D10016A87FC1EDf
SHA-1: 8DB8AD90505D9A2B4485E903B9F5D67BB9C0C149



______________________________________________________________



Minimum: critical fixes


gbc_compatible.ips
*  Playable on Color, Advance handhelds



_______________________________________________



Commits:


1 - [2021-08-30]
*  gbc_compatible released



_______________________________________________



Visit:
*  https://github.com/minucce-yard/Legend_of_Xerd_GB




Helpful:
*  BGB -- incredibly helpful debugger
*  SameBoy -- very high recreation of Game Boy



_________________________________________________________



Compile:

*  Z80 armips assembler by Prof9
   https://github.com/Prof9/armips/tree/gameboy



*  Copy @__build files to root folder  (one up)

   armips "legend_zerd.asm.txt"
   rgbfix -fgh "Zerd no Densetsu (Japan).gb"
